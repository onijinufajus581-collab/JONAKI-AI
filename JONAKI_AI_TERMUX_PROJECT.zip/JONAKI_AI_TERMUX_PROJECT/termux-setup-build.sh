#!/data/data/com.termux/files/usr/bin/bash
set -e
echo "[1/3] Installing Termux packages..."
pkg update -y
pkg install proot-distro unzip -y
echo "[2/3] Installing Debian..."
proot-distro install debian || true
echo "[3/3] Debian installed."
echo
echo "Now run: proot-distro login debian"
echo "Then access the project from /sdcard/Download if you extracted it there,"
echo "or copy it into Debian /root/JONAKI_AI and run: bash debian-build.sh"
