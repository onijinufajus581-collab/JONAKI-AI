#!/usr/bin/env bash
set -euo pipefail
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
echo "Installing build prerequisites..."
apt-get update
apt-get install -y openjdk-17-jdk wget unzip zip curl
export JAVA_HOME="$(dirname "$(dirname "$(readlink -f "$(command -v javac)")")")"
export PATH="$JAVA_HOME/bin:$PATH"
GRADLE_VERSION=8.7
if ! command -v gradle >/dev/null 2>&1; then
  cd /tmp
  wget -q "https://services.gradle.org/distributions/gradle-${GRADLE_VERSION}-bin.zip"
  unzip -q -o "gradle-${GRADLE_VERSION}-bin.zip"
  export PATH="/tmp/gradle-${GRADLE_VERSION}/bin:$PATH"
fi
export ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
mkdir -p "$ANDROID_HOME/cmdline-tools"
if [ ! -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  cd /tmp
  wget -q https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip -O android-cli.zip
  unzip -q -o android-cli.zip
  mkdir -p "$ANDROID_HOME/cmdline-tools/latest"
  cp -r cmdline-tools/* "$ANDROID_HOME/cmdline-tools/latest/"
fi
export PATH="$ANDROID_HOME/cmdline-tools/latest/bin:$ANDROID_HOME/platform-tools:$PATH"
yes | sdkmanager --licenses >/dev/null || true
sdkmanager "platform-tools" "platforms;android-35" "build-tools;35.0.0"
cd "$PROJECT_DIR"
gradle --no-daemon assembleDebug
mkdir -p output
cp app/build/outputs/apk/debug/app-debug.apk output/JONAKI_AI.apk
echo "APK: $PROJECT_DIR/output/JONAKI_AI.apk"
