package com.jonaki.ai;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.*;

public class SettingsActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences prefs = getSharedPreferences("jonaki", MODE_PRIVATE);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 32, 24, 24);
        root.setBackgroundColor(Color.rgb(9,9,20));
        TextView title = new TextView(this);
        title.setText("জনাকি AI — সেটিংস");
        title.setTextColor(Color.WHITE); title.setTextSize(24); title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView hint = new TextView(this);
        hint.setText("Gemini API Key"); hint.setTextColor(Color.CYAN); hint.setPadding(0,32,0,8);
        root.addView(hint);
        EditText key = new EditText(this);
        key.setSingleLine(true); key.setHint("এখানে API Key দিন");
        key.setText(prefs.getString("api_key",""));
        key.setTextColor(Color.WHITE); key.setHintTextColor(Color.GRAY);
        root.addView(key);
        Button save = new Button(this); save.setText("API Key সংরক্ষণ করুন");
        root.addView(save);
        save.setOnClickListener(v -> {
            prefs.edit().putString("api_key", key.getText().toString().trim()).apply();
            Toast.makeText(this, "API Key সংরক্ষণ হয়েছে", Toast.LENGTH_SHORT).show();
            finish();
        });
        setContentView(root);
    }
}
