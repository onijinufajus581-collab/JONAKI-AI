package com.jonaki.ai;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private LinearLayout messages;
    private EditText input;
    private TextToSpeech tts;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private static final int SPEECH_REQUEST = 71;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) tts.setLanguage(new Locale("bn", "BD"));
        });
        buildUI();
        addMessage("জনাকি AI", "আসসালামু আলাইকুম! আমি জনাকি AI। কীভাবে সাহায্য করতে পারি?");
    }

    private void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14, 12, 14, 12);
        root.setBackgroundColor(Color.rgb(9,9,20));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView brand = new TextView(this);
        brand.setText("✦  জনাকি AI");
        brand.setTextColor(Color.rgb(0,229,255)); brand.setTextSize(25); brand.setPadding(8,12,8,12);
        header.addView(brand, new LinearLayout.LayoutParams(0,-2,1));
        Button settings = new Button(this); settings.setText("সেটিংস");
        header.addView(settings);
        settings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
        root.addView(header);

        TextView subtitle = new TextView(this);
        subtitle.setText("আপনার বাংলা AI সহকারী  •  বাংলাদেশ");
        subtitle.setTextColor(Color.LTGRAY); subtitle.setGravity(Gravity.CENTER);
        root.addView(subtitle);

        ScrollView scroll = new ScrollView(this);
        messages = new LinearLayout(this); messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(4,16,4,16);
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        LinearLayout actions = new LinearLayout(this);
        Button voice = new Button(this); voice.setText("🎙 কথা বলুন");
        Button youtube = new Button(this); youtube.setText("YouTube");
        actions.addView(voice, new LinearLayout.LayoutParams(0,-2,1));
        actions.addView(youtube, new LinearLayout.LayoutParams(0,-2,1));
        root.addView(actions);
        voice.setOnClickListener(v -> startVoice());
        youtube.setOnClickListener(v -> {
            String q = input.getText().toString().trim();
            if (q.isEmpty()) q = "বাংলা গান";
            Intent i = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/results?search_query=" + android.net.Uri.encode(q)));
            startActivity(i);
        });

        LinearLayout composer = new LinearLayout(this);
        input = new EditText(this);
        input.setHint("বাংলায় লিখুন...");
        input.setTextColor(Color.WHITE); input.setHintTextColor(Color.GRAY);
        composer.addView(input, new LinearLayout.LayoutParams(0,-2,1));
        Button send = new Button(this); send.setText("পাঠান");
        composer.addView(send);
        root.addView(composer);
        send.setOnClickListener(v -> sendMessage());
        setContentView(root);
    }

    private void addMessage(String who, String text) {
        TextView tv = new TextView(this);
        tv.setText(who + "\n" + text);
        tv.setTextColor(Color.WHITE); tv.setTextSize(16);
        tv.setPadding(16,12,16,12);
        tv.setBackgroundColor(who.equals("আপনি") ? Color.rgb(42,28,75) : Color.rgb(23,31,52));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,8,0,8);
        messages.addView(tv, lp);
    }

    private void sendMessage() {
        String prompt = input.getText().toString().trim();
        if (prompt.isEmpty()) return;
        input.setText("");
        addMessage("আপনি", prompt);
        addMessage("জনাকি AI", "উত্তর তৈরি করছি...");
        int loadingIndex = messages.getChildCount()-1;
        SharedPreferences p = getSharedPreferences("jonaki", MODE_PRIVATE);
        String key = p.getString("api_key", "");
        executor.execute(() -> {
            String answer;
            try { answer = GeminiClient.ask(key, prompt); }
            catch (Exception e) { answer = "দুঃখিত, সমস্যা হয়েছে: " + e.getMessage(); }
            final String result = answer;
            runOnUiThread(() -> {
                if (loadingIndex < messages.getChildCount()) messages.removeViewAt(loadingIndex);
                addMessage("জনাকি AI", result);
                if (tts != null) tts.speak(result, TextToSpeech.QUEUE_FLUSH, null, "jonaki_reply");
            });
        });
    }

    private void startVoice() {
        try {
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
            i.putExtra(RecognizerIntent.EXTRA_PROMPT, "জনাকিকে বাংলায় বলুন");
            startActivityForResult(i, SPEECH_REQUEST);
        } catch (Exception e) {
            Toast.makeText(this, "এই ফোনে Voice Recognition চালু করা যায়নি।", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SPEECH_REQUEST && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) {
                input.setText(results.get(0));
                sendMessage();
            }
        }
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        executor.shutdownNow();
    }
}
