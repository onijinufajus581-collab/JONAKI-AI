package com.jonaki.ai;

import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class GeminiClient {
    public static String ask(String apiKey, String prompt) throws Exception {
        if (apiKey == null || apiKey.trim().isEmpty()) throw new Exception("Settings থেকে Gemini API Key যোগ করুন।");
        URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + apiKey.trim());
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(20000);
        c.setReadTimeout(60000);
        c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json; charset=UTF-8");

        JSONObject part = new JSONObject();
        part.put("text", "তুমি জনাকি AI, বাংলাদেশের একজন সহায়ক বাংলা AI সহকারী। স্বাভাবিক বাংলাদেশি বাংলায় উত্তর দাও। প্রয়োজন হলে কোডের syntax ইংরেজিতে রাখবে, কিন্তু ব্যাখ্যা বাংলায় দেবে। ব্যবহারকারীর প্রশ্ন: " + prompt);
        JSONObject content = new JSONObject();
        content.put("parts", new JSONArray().put(part));
        JSONObject body = new JSONObject();
        body.put("contents", new JSONArray().put(content));

        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes("UTF-8"));
        }
        int code = c.getResponseCode();
        InputStream is = code >= 200 && code < 300 ? c.getInputStream() : c.getErrorStream();
        StringBuilder response = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"))) {
            String line;
            while ((line = br.readLine()) != null) response.append(line);
        }
        c.disconnect();
        JSONObject json = new JSONObject(response.toString());
        if (code < 200 || code >= 300) {
            String msg = json.optJSONObject("error") != null ? json.getJSONObject("error").optString("message", "API error") : "API error";
            throw new Exception("Gemini API: " + msg);
        }
        return json.getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0).optString("text", "উত্তর পাওয়া যায়নি।");
    }
}
